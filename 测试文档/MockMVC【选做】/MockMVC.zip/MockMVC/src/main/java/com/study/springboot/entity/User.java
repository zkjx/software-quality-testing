package com.study.springboot.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author 何翔
 * @since 2021-10-06
 */
@Data
public class User implements Serializable {
    private String userName;
    private String userPwd;
}
