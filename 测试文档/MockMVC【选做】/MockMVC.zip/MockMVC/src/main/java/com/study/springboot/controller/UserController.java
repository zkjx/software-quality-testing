package com.study.springboot.controller;


import com.study.springboot.entity.User;
import com.study.springboot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 何翔
 * @since 2021-10-06
 */
@RestController
@RequestMapping("/springboot/user")
public class UserController {

    @Autowired
    private UserService userService;


    @RequestMapping("/test/save")
    public String saveUser(@RequestBody User user){
        if(userService.save(user))return "success";
        else return "error";
    }


}

