package com.study.springboot.service.impl;

import com.study.springboot.entity.User;
import com.study.springboot.service.UserService;
import org.springframework.stereotype.Service;



@Service
public class UserServiceImpl  implements UserService {

    @Override
    public boolean save(User user) {
        return true;
    }
}



