package com.study.springboot.service;

import com.study.springboot.entity.User;


public interface UserService  {

    boolean save(User user);
}