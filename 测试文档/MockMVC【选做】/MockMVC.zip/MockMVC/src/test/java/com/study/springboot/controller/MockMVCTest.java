package com.study.springboot.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.study.springboot.entity.User;
import com.study.springboot.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


/*
 * @ClassName UserControllerTest
 * @description: TODO
 * @author: 何翔
 * @Date 2022/1/1 1:38
 */

@SpringBootTest
@AutoConfigureMockMvc
class MockMVCTest {

    @MockBean
    private UserService userService;

    @Autowired
    private MockMvc mockMvc;//mock工具的依赖注入

    @Autowired
    ObjectMapper objectMapper;


    @Test
    public void save() throws Exception {
        /*
         * @author: 何翔
         * @param: []
         * @return: void
         * @date: 2021/12/31 14:42
         * @description：使用mockMvc模拟请求测试添加用户
         */
        User user = new User();
        user.setUserName("李四");
        user.setUserPwd("456");
        when(userService.save(isA(User.class))).thenReturn(true);
        MvcResult result = mockMvc.perform(post("/springboot/user/test/save")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(user)))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();
        System.out.println(result);
        this.mockMvc.perform(post("/springboot/user/test/save")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(user)))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").value("success"));
    }
}